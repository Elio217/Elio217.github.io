using System.Buffers.Binary;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Windows.Media;

internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        if (args.Length is < 2 or > 4)
        {
            Console.Error.WriteLine("usage: WpfKernLengthHarness <font-file> <output-font> [glyph-count] [--debug-break]");
            return 64;
        }

        string inputPath = Path.GetFullPath(args[0]);
        string outputPath = Path.GetFullPath(args[1]);
        int glyphCount = args.Length == 3
            ? int.Parse(args[2], System.Globalization.CultureInfo.InvariantCulture)
            : 1;

        string presentationCorePath = typeof(GlyphTypeface).Assembly.Location;
        string nativeModulePath = Path.Combine(Path.GetDirectoryName(presentationCorePath)!, "DirectWriteForwarder.dll");
        Console.WriteLine($"runtime={Environment.Version}");
        LogModule("PresentationCore", presentationCorePath);
        LogModule("DirectWriteForwarder", nativeModulePath);
        Console.WriteLine($"input_path={inputPath}");
        Console.WriteLine($"input_sha256={Sha256File(inputPath)}");
        Console.WriteLine($"glyph_count={glyphCount}");

        byte[] input = File.ReadAllBytes(inputPath);
        TableRange inputKern = FindTable(input, "kern");
        Console.WriteLine($"input_kern_offset={inputKern.Offset}");
        Console.WriteLine($"input_kern_length={inputKern.Length}");

        var typeface = new GlyphTypeface(new Uri(inputPath, UriKind.Absolute));
        _ = typeface.GlyphCount;
        ushort[] glyphs = Enumerable.Range(0, glyphCount).Select(index => checked((ushort)index)).ToArray();
        if (args.Length == 4 && args[3] == "--debug-break")
        {
            Debugger.Break();
        }
        byte[] output = typeface.ComputeSubset(glyphs);

        Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
        File.WriteAllBytes(outputPath, output);
        Console.WriteLine($"output_size={output.Length}");
        Console.WriteLine($"output_sha256={Convert.ToHexString(SHA256.HashData(output)).ToLowerInvariant()}");

        TableRange outputKern = FindTable(output, "kern");
        Console.WriteLine($"output_kern_offset={outputKern.Offset}");
        Console.WriteLine($"output_kern_length={outputKern.Length}");
        int sharedLength = Math.Min(inputKern.Length, outputKern.Length);
        ReadOnlySpan<byte> expansion = output.AsSpan(outputKern.Offset + sharedLength, outputKern.Length - sharedLength);
        Console.WriteLine($"output_kern_expansion_length={expansion.Length}");
        Console.WriteLine($"output_kern_expansion_nonzero={CountNonzero(expansion)}");
        Console.WriteLine($"output_kern_expansion_sha256={Convert.ToHexString(SHA256.HashData(expansion)).ToLowerInvariant()}");
        Console.WriteLine($"output_kern_expansion_hex={Convert.ToHexString(expansion).ToLowerInvariant()}");
        return 0;
    }

    private static void LogModule(string label, string path)
    {
        FileVersionInfo version = FileVersionInfo.GetVersionInfo(path);
        Console.WriteLine($"{label}_version={version.FileVersion}");
        Console.WriteLine($"{label}_product_version={version.ProductVersion}");
        Console.WriteLine($"{label}_sha256={Sha256File(path)}");
    }

    private static string Sha256File(string path)
    {
        using FileStream stream = File.OpenRead(path);
        return Convert.ToHexString(SHA256.HashData(stream)).ToLowerInvariant();
    }

    private static TableRange FindTable(ReadOnlySpan<byte> font, string wantedTag)
    {
        if (font.Length < 12) throw new InvalidDataException("truncated sfnt header");
        int tableCount = BinaryPrimitives.ReadUInt16BigEndian(font.Slice(4, 2));
        for (int index = 0; index < tableCount; index++)
        {
            int entryOffset = checked(12 + 16 * index);
            if (entryOffset + 16 > font.Length) throw new InvalidDataException("truncated sfnt directory");
            string tag = System.Text.Encoding.ASCII.GetString(font.Slice(entryOffset, 4));
            int offset = checked((int)BinaryPrimitives.ReadUInt32BigEndian(font.Slice(entryOffset + 8, 4)));
            int length = checked((int)BinaryPrimitives.ReadUInt32BigEndian(font.Slice(entryOffset + 12, 4)));
            if (tag == wantedTag)
            {
                if (offset < 0 || length < 0 || offset > font.Length - length)
                    throw new InvalidDataException("table range exceeds font buffer");
                return new TableRange(offset, length);
            }
        }

        throw new InvalidDataException($"missing {wantedTag} table");
    }

    private static int CountNonzero(ReadOnlySpan<byte> value)
    {
        int count = 0;
        foreach (byte item in value) if (item != 0) count++;
        return count;
    }

    private readonly record struct TableRange(int Offset, int Length);
}
