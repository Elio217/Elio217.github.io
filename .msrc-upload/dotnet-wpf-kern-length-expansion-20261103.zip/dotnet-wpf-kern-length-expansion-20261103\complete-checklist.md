# Complete-report checklist

Checked against Microsoft's current requirements on 2026-11-03 KST.

- [x] Current individual-program product/version scope: .NET 10.0.14 is the
      latest supported active LTS patch.
- [x] Bounty qualification is assessed separately and not asserted.
- [x] Type: uninitialized native memory information disclosure.
- [x] Reliable minimized PoC, source, build files, fixtures, and run script.
- [x] Exact runtime, module versions/hashes, OS build, and BuildLabEx.
- [x] Attacker input, starting privilege, host/user-interaction dependency,
      and returned-data path explained.
- [x] Root cause and nested-range/output-initialization invariants identified.
- [x] Five fresh controls and five fresh attackers included and verified.
- [x] Confirmed 506-byte result separated from hypothetical host impact.
- [x] Native/managed call stack included.
- [x] User `.dump /mpwdF` included with SHA-256.
- [x] Native trace proves exact arguments and checks skipped.
- [x] Debugger-output fill and natural outputs included.
- [x] Distinctness from `VULN-256462` explained.
- [x] Public related-fix context included without claiming no duplicate.
- [x] Portal fields are self-contained rather than attachment-only.
- [x] No real secret, arbitrary-address read, OOB write, crash, RCE, EoP,
      tenant impact, severity, CVE, or bounty claim.

Conclusion: ready for attachment-manifest audit and portal submission.

