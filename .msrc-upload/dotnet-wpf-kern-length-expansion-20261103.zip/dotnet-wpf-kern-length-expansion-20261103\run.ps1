param(
    [string]$SdkDotnet = "dotnet",
    [string]$RuntimeDotnet = "dotnet",
    [string]$Python = "python",
    [ValidateRange(1, 20)]
    [int]$RepeatCount = 5,
    [switch]$SkipBuild
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$Root = $PSScriptRoot
$Project = Join-Path $Root "harness\WpfKernLengthHarness.csproj"
$Harness = Join-Path $Root "harness\bin\Release\net10.0-windows\WpfKernLengthHarness.dll"
$Control = Join-Path $Root "fixtures\kern-format1-length-6.ttf"
$Attacker = Join-Path $Root "fixtures\kern-format1-length-512.ttf"
$Verifier = Join-Path $Root "verify_outputs.py"
$RunId = Get-Date -Format "yyyyMMdd-HHmmss"
$EvidenceRoot = Join-Path $Root "repro-evidence-$RunId"
$ControlRoot = Join-Path $EvidenceRoot "clean-control"
$AttackerRoot = Join-Path $EvidenceRoot "clean-attacker"

New-Item -ItemType Directory -Force -Path $ControlRoot, $AttackerRoot | Out-Null

if (-not $SkipBuild) {
    & $SdkDotnet build $Project -c Release
    if ($LASTEXITCODE -ne 0) { throw "dotnet build failed: $LASTEXITCODE" }
}

if (-not (Test-Path -LiteralPath $Harness -PathType Leaf)) {
    throw "Harness not found: $Harness"
}

function Invoke-Probe {
    param(
        [Parameter(Mandatory = $true)][string]$Group,
        [Parameter(Mandatory = $true)][string]$InputFont,
        [Parameter(Mandatory = $true)][string]$OutputRoot,
        [Parameter(Mandatory = $true)][int]$Index
    )

    $Stem = "{0}-{1:D2}" -f $Group, $Index
    $OutputFont = Join-Path $OutputRoot "$Stem.ttf"
    $Log = Join-Path $OutputRoot "$Stem.log"
    & $RuntimeDotnet $Harness $InputFont $OutputFont 1 2>&1 | Tee-Object -FilePath $Log
    if ($LASTEXITCODE -ne 0) { throw "$Stem failed: $LASTEXITCODE" }
}

for ($Index = 1; $Index -le $RepeatCount; $Index++) {
    Invoke-Probe -Group "control" -InputFont $Control -OutputRoot $ControlRoot -Index $Index
}

for ($Index = 1; $Index -le $RepeatCount; $Index++) {
    Invoke-Probe -Group "attacker" -InputFont $Attacker -OutputRoot $AttackerRoot -Index $Index
}

$VerificationLog = Join-Path $EvidenceRoot "verification.csv"
& $Python $Verifier --input-font $Attacker --control-font $Control --evidence-root $EvidenceRoot 2>&1 |
    Tee-Object -FilePath $VerificationLog
if ($LASTEXITCODE -ne 0) { throw "verification failed: $LASTEXITCODE" }

Write-Host "Evidence: $EvidenceRoot"
