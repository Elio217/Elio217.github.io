# .NET 10.0.14 WPF `ModKern` serializes 506 bytes of uninitialized native heap after nested-length expansion

## Summary

A ten-byte TrueType `kern` table containing one unsupported format-1 subtable
declares that nested subtable as 512 bytes long. WPF's native subsetter accepts
the table. Because the first subtable's source and target offsets are equal,
`CopyBlock` returns before its source/destination range checks. `ModKern` then
advances the output cursor by the attacker length and publishes a 516-byte
table even though only ten bytes were supplied or copied. Public
`GlyphTypeface.ComputeSubset` returns the resulting font with 506 unwritten
native-allocation bytes.

Five fresh controls retained a ten-byte table with no expansion. Five fresh
attackers returned a 516-byte table; every 506-byte expansion contained
nonzero data and all hashes differed. A debugger run captured the exact
source-equals-target branch and returned the full expansion as Windows
debug-heap `F00DBAAD` fill.

## Target

- Microsoft .NET / `Microsoft.WindowsDesktop.App` 10.0.14 x64
- Windows 11 Home 25H2 x64, build `26200.9711`; BuildLabEx
  `26100.1.amd64fre.ge_release.240331-1435`
- `PresentationCore.dll` 10.0.1426.52326, SHA-256
  `131faa87bce352c2c7ea02fa6d6c36533992fd77a3bf429d1145d21ef3650f1d`
- `DirectWriteForwarder.dll` 10.0.1426.52326 / product
  `10.0.14-servicing.26522.126`, commit
  `0427b9abbead3fa64c6655eb4290c537397131fa`, SHA-256
  `84a254d16d68bdea52981338cb9ed5a2cc52369b51c8c91e72c4714ee2ad199e`

Other versions and architectures were not executed and are not claimed.

## Attack conditions and returned-data path

An attacker controls a malformed TrueType font and can cause a host to subset
it through WPF. Confidentiality impact requires that host to return or store
the generated subset where the font supplier can read it. The attacker needs
no administrator rights, debugger, disabled mitigation, or memory/control-flow
modification. User interaction and remote reachability depend on the host;
WPF alone is not asserted to create a network or tenant boundary.

`ModKern` publishes the expanded table in the native output font.
`TrueTypeSubsetter.ComputeSubset` copies that result into managed memory, and
public `GlyphTypeface.ComputeSubset` returns it as `byte[]`. A host exposing
that byte array exposes the unwritten bytes to the supplier.

## Root cause and invariant

At WPF tag `v10.0.14`, `modtable.cpp:642-648` checks only that the count of
six-byte subtable headers fits the `kern` directory length. It does not
validate each declared nested length. Lines 654-665 make the first subtable's
source and target equal and call `CopyBlock(..., length=512)`. In
`ttftabl1.cpp:566`, `CopyBlock` returns on equality before the range checks at
lines 571 and 576. Because the format is not zero, `ModKern` advances the
target by 512 at line 679 and publishes length 516 at line 686.

The violated invariant is: every nested subtable range and every published
output byte must be contained in the original logical `kern` range or be
explicitly initialized. Equality of copy offsets must not bypass validation.

Sources:

- https://github.com/dotnet/wpf/blob/v10.0.14/src/Microsoft.DotNet.Wpf/src/DirectWriteForwarder/CPP/TrueTypeSubsetter/TtfDelta/modtable.cpp#L603-L688
- https://github.com/dotnet/wpf/blob/v10.0.14/src/Microsoft.DotNet.Wpf/src/DirectWriteForwarder/CPP/TrueTypeSubsetter/TtfDelta/ttftabl1.cpp#L554-L588

## Debugger evidence and call stack

At the captured instruction, private Microsoft symbols show:

```text
CopyBlock+0x20: cmp esi,edi
target=0xed0 source=0xed0 size=0x200
```

The next equality jump bypasses both checks. The stack is:

```text
DirectWriteForwarder!CopyBlock
DirectWriteForwarder!ModKern+0x1ac
DirectWriteForwarder!CreateDeltaTTFEx+0x553
DirectWriteForwarder!CreateDeltaTTF+0x3ef
DirectWriteForwarder!MS.Internal.TrueTypeSubsetter.ComputeSubset+0x1a4
PresentationCore!TrueTypeFontDriver.ComputeFontSubset+0x8a
PresentationCore!GlyphTypeface.ComputeSubset+0xb6
WpfKernLengthHarness!Program.Main+0x65e
```

The included user `.dump /mpwdF` SHA-256 is
`3ffafe0b3c9d5582e829f551a58a963a3e37cdd23bcc03194a33ac417d8b34e9`.
The debugger output's 506-byte expansion is entirely `F00DBAAD` allocation
fill. The five unmodified runs prove the same region naturally varies and is
nonzero; the debugger is observation-only.

## Confirmed impact and limitations

Confirmed: the returned font contains 506 bytes not supplied by the input and
not initialized by this path. This is an uninitialized native-memory
confidentiality violation. No real secret was identified. I do not claim an
attacker-selected address, OOB write, crash, RCE, EoP, tenant impact,
Important/Critical severity, CVE assignment, or bounty qualification. Host
behavior determines whether a security boundary is crossed.

## Distinctness and duplicate uncertainty

My earlier `VULN-256462` is a format-0 excessive-pair-count read in
`AdjustKernFormat0`. This report never enters that function: it uses format 1,
the `CopyBlock` equality fast path, and directory expansion over unwritten
output bytes. The root cause and disclosure mechanism are distinct.

Public PR #11835 added count and format-0 hardening; PR #11877 changed only a
format-0 pair-array bound. The current release branch retains this path. No
exact public report was found, but a private or unindexed duplicate is
possible. The .NET program's Important/Critical threshold and common
server-side-information-disclosure exclusion are acknowledged.

## Remediation

Validate every nested subtable's minimum size and complete range against the
original `kern` directory range with overflow-safe arithmetic before any copy
or cursor advance. Perform range validation even when source equals target,
and never publish a table length beyond bytes actually copied or initialized.

