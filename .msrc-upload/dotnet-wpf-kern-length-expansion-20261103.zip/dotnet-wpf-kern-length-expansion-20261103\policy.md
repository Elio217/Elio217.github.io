# Policy assessment

Checked 2026-11-03 KST against official Microsoft material.

## Product scope and award distinction

- .NET Bounty Program:
  https://www.microsoft.com/en-us/msrc/bounty-dot-net-core
- .NET support policy:
  https://dotnet.microsoft.com/en-us/platform/support/policy/dotnet-core

The individual program includes current supported Microsoft .NET versions.
The official support table, last updated 2026-10-25, lists .NET 10 as active
LTS, 10.0.14 as its latest patch, and support through 2028-11-14. The tested
Windows Desktop Runtime is therefore in product/version scope.

That does not establish award eligibility. The program requires Critical or
Important severity for an individual-program award and lists server-side
information disclosure and user-generated content among common non-paying
cases. This report therefore separates product scope, possible servicing,
Complete status, and award qualification and asserts none of the latter.

## Complete-report requirements

- https://www.microsoft.com/en-us/msrc/requirements-for-complete-vulnerability-reports

The current requirements apply to reports submitted on or after 2026-10-20
08:00 PT and assess completeness from the initial submission. General
requirements include a minimized reliable PoC, type, correct root cause,
exact environment, attack conditions, impact, and affected component.
Endpoint/On-Prem information disclosure additionally requires an explanation
of how data reaches the attacker, a call stack, PoC source/script, and a user
`.dump /mpwdF` or TTD trace.

The portal narrative is self-contained. The attachment adds source, fixtures,
five fresh controls, five fresh attacker outputs, an automated verifier,
native debugger logs, and the required user dump.

## Rules, Safe Harbor, and disclosure

- Security vulnerability definition:
  https://www.microsoft.com/en-us/msrc/definition-of-a-security-vulnerability
- Rules of Engagement:
  https://www.microsoft.com/en-us/msrc/pentest-rules-of-engagement
- Bounty terms and Legal Safe Harbor:
  https://www.microsoft.com/en-us/msrc/bounty-guidelines
- Coordinated Vulnerability Disclosure:
  https://www.microsoft.com/en-us/msrc/cvd

Testing used only researcher-controlled local files, processes, and synthetic
data. No Microsoft, customer, cloud, or third-party data was accessed. No
public disclosure is planned.

## Public change and duplicate context

- WPF hardening PR #11835:
  https://github.com/dotnet/wpf/pull/11835
- WPF format-0 regression fix PR #11877:
  https://github.com/dotnet/wpf/pull/11877
- `ModKern` source:
  https://github.com/dotnet/wpf/blob/v10.0.14/src/Microsoft.DotNet.Wpf/src/DirectWriteForwarder/CPP/TrueTypeSubsetter/TtfDelta/modtable.cpp#L603-L688
- `CopyBlock` source:
  https://github.com/dotnet/wpf/blob/v10.0.14/src/Microsoft.DotNet.Wpf/src/DirectWriteForwarder/CPP/TrueTypeSubsetter/TtfDelta/ttftabl1.cpp#L554-L588

PR #11835 publicly added a minimum `nTables * 6` check and format-0 pair
hardening. PR #11877 changed only the format-0 pair-array comparison for valid
tables larger than 64 KiB. Neither validates each unsupported subtable's
declared range before the first equality fast path. The tested tagged source
and current `release/10.0` retain identical relevant files.

Official-repository searches on 2026-11-03 found no issue or PR describing
this exact non-format-0 length-expansion/unwritten-output path. That is only a
public-search result; a private or unindexed duplicate remains possible.

