# Analysis and evidence classification

## Hypothesis before testing

**HYPOTHESIS:** An untrusted font supplier controls the nested length of an
unsupported legacy `kern` subtable. When a host subsets that font through WPF
and exposes the returned subset, a first-subtable source/target equality can
skip range validation, expand the logical output table, and return native
allocation bytes that the supplier did not provide.

Cheapest falsification experiment: compare otherwise identical ten-byte
format-1 `kern` tables whose nested length is either the valid header size 6
or 512. Run each through public `GlyphTypeface.ComputeSubset` in fresh
processes, parse the returned table directory, and inspect only bytes beyond
the ten-byte input table.

## Facts

- **FACT:** The attacker and control fixtures are identical base fonts. Their
  only relevant change is the nested `kern` subtable length: 512 versus 6.
  Both physical and table-directory `kern` lengths are ten bytes.
- **FACT:** The attacker `kern` bytes are
  `00 00 00 01 00 01 02 00 01 01`: version 0, one subtable, subtable version
  1, length `0x0200`, format 1/coverage 1.
- **FACT:** `ModKern`'s preliminary check validates only
  `nTables * SIZEOF_KERN_SUB_HEADER <= table length`; one six-byte header
  passes inside a ten-byte table.
- **FACT:** For the first subtable, source and target both start four bytes
  after the table start. `ModKern` passes the attacker length to `CopyBlock`.
- **FACT:** `CopyBlock` returns `NO_ERROR` when source equals target before
  calling `CheckInOffset` or `CheckOutOffset`.
- **FACT:** Because format 1 is not rewritten, `ModKern` advances the target
  by 512 and updates the `kern` directory length to `4 + 512 = 516`.
- **FACT:** Five fresh control processes returned identical 4,768-byte fonts
  with `kern` length 10 and no expansion.
- **FACT:** Five fresh attacker processes returned 5,272-byte fonts with
  `kern` length 516. Each contains a 506-byte expansion with nonzero counts
  142, 196, 216, 216, and 206; all expansion and whole-file hashes differ.
- **FACT:** At the vulnerable call, private Microsoft symbols show
  `target=0xed0`, `source=0xed0`, `size=0x200`. Disassembly shows the equality
  comparison branching over both range checks.
- **FACT:** The debugger-run 506-byte expansion is entirely the repeating
  little-endian debug-heap fill `ad ba 0d f0` (`F00DBAAD`), including the final
  two-byte partial repeat. None of those 506 bytes exists in the input table.
- **FACT:** The native and managed stack reaches this code through public
  `System.Windows.Media.GlyphTypeface.ComputeSubset` without modifying memory,
  registers, or control flow. The debugger is observation-only.
- **FACT:** A user `.dump /mpwdF` was captured at the equality comparison.

## Inferences

- **INFERENCE:** The 506 published bytes are unwritten native output-allocation
  contents. This follows from the source path, varying natural outputs, and
  full debug-heap fill in the instrumented output.
- **INFERENCE:** Natural outputs contain process-layout-like values, but their
  meaning was not dereferenced or attributed to a particular secret.
- **INFERENCE:** A host that accepts a supplier-controlled font and returns the
  subset crosses a confidentiality boundary. WPF alone does not create a
  remote or tenant boundary, so host reachability is deployment-dependent.

## Confirmed impact and limits

Confirmed: the supported API returns 506 bytes that are neither supplied by
the font nor initialized by this path. This is uninitialized-memory
information disclosure in the derived font.

Not confirmed: a real secret, attacker-selected address, stable meaning for
the returned values, cross-user/tenant reachability, OOB write, crash, code
execution, privilege elevation, Important/Critical severity, CVE assignment,
or bounty qualification.

## Distinctness from `VULN-256462`

`VULN-256462` uses a format-0 subtable and an excessive `nPairs`; the vulnerable
operation is pair processing in `AdjustKernFormat0`, which reads across the
logical `kern` boundary and serializes a synthetic prior-call value.

This candidate uses an unsupported format-1 subtable and never enters
format-0 pair processing. The vulnerable operations are the untrusted
subtable-length copy request, `CopyBlock`'s equality fast path before bounds
checks, and `UpdateDirEntry` publishing a length larger than initialized data.
The returned 506-byte region is unwritten output memory. The inputs, code path,
root cause, and disclosure mechanism are distinct.

## Proposed remediation

Before copying or advancing, validate every nested subtable with overflow-safe
arithmetic: length at least six and the complete `[source, source+length)`
range contained within the original `kern` directory range. Perform range
validation even when source equals target; move the equality fast return after
the checks or validate at the caller. Never update the directory entry beyond
bytes actually copied or initialized.

## Remaining uncertainty and next validation

The important remaining uncertainty is host-specific security-boundary and
severity classification. The next useful validation, if MSRC requests it, is
an identified Microsoft-supported producer/consumer workflow that returns a
WPF-generated subset across a user boundary. Additional parser-only runs are
unlikely to change the established root cause.

