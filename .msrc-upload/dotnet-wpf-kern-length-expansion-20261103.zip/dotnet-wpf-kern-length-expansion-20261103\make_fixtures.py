#!/usr/bin/env python3
from pathlib import Path
from struct import pack

from fontTools.ttLib import TTFont
from fontTools.ttLib.tables.DefaultTable import DefaultTable


ROOT = Path(__file__).resolve().parent
FIXTURES = ROOT / "fixtures"
SOURCE = FIXTURES / "base-control.ttf"
if not SOURCE.exists():
    SOURCE = ROOT.parent / "dotnet-wpf-font-subsetter" / "fixtures" / "DejaVuSans-small-control.ttf"


def build(path: Path, subtable_length: int) -> None:
    # Apple/Microsoft legacy kern header: version=0, nTables=1.
    # The subtable is unsupported format 1 (coverage high byte == 1), so
    # ModKern copies it rather than rewriting format-0 pairs.
    raw_kern = pack(">HH", 0, 1) + pack(">HHH", 1, subtable_length, 0x0101)
    assert len(raw_kern) == 10

    font = TTFont(SOURCE, recalcBBoxes=False, recalcTimestamp=False)
    table = DefaultTable("kern")
    table.data = raw_kern
    font["kern"] = table
    font.save(path, reorderTables=False)

    check = TTFont(path, lazy=True)
    entry = check.reader.tables["kern"]
    print(
        f"path={path} size={path.stat().st_size} glyphs={check['maxp'].numGlyphs} "
        f"kern_offset={entry.offset} kern_length={entry.length} declared_subtable_length={subtable_length}"
    )
    check.close()


FIXTURES.mkdir(parents=True, exist_ok=True)
for length in (6, 10, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 0x4000):
    build(FIXTURES / f"kern-format1-length-{length}.ttf", length)
