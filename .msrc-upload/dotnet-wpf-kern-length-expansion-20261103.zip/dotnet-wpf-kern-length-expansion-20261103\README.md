# WPF `kern` declared-length expansion disclosure candidate

Status: independently reproduced and Complete-report package preparation in
progress; not yet submitted.

- Final report: [report-final.md](report-final.md)
- Portal-ready fields: [portal-fields.md](portal-fields.md)
- Reproduction: [reproduction.md](reproduction.md)
- Evidence classification: [analysis.md](analysis.md)
- Policy assessment: [policy.md](policy.md)
- Complete checklist: [complete-checklist.md](complete-checklist.md)
- Evidence summary: [evidence/verification-summary.txt](evidence/verification-summary.txt)
- Source and environment state: [evidence/source-state.txt](evidence/source-state.txt),
  [evidence/environment.txt](evidence/environment.txt)

Current result: a 10-byte TrueType `kern` table contains one unsupported
format-1 subtable whose header declares length 512. On the first subtable,
`ModKern` calls `CopyBlock` with identical source and target offsets.
`CopyBlock` returns before either range check, and `ModKern` advances the
output offset by the untrusted length and publishes a 516-byte `kern` table.
Only ten bytes were supplied or copied, so the returned subset exposes 506
unwritten bytes from the native output allocation.

Five fresh control processes retained a 10-byte `kern` with no expansion.
Five fresh attacker processes returned a 516-byte `kern`; every 506-byte
expansion contained nonzero data and all five hashes differed. At the exact
vulnerable call, the debugger recorded `target=source=0xed0`, `size=0x200`,
the equality branch that skips the checks, and the supported
`GlyphTypeface.ComputeSubset` stack. Its output expansion is all Windows
debug-heap `F00DBAAD` fill, proving that the input did not supply those bytes.

Confirmed impact is uninitialized native heap data in the returned font. A
security boundary requires a host that accepts an attacker font and returns
or stores the generated subset where the attacker can read it. No real secret,
arbitrary-address read, OOB write, crash, RCE, EoP, tenant boundary, severity,
CVE, or bounty is claimed. This root cause is distinct from submitted
`VULN-256462`, which used format-0 pair-count reads across a logical boundary.

