# MSRC portal fields

## Title

.NET 10.0.14 WPF ModKern returns 506 uninitialized native heap bytes after nested-length expansion

## Vulnerability description

### Summary

A ten-byte TrueType `kern` table contains one unsupported format-1 subtable
whose nested header declares length 512. WPF accepts it. Because the first
subtable's source and target offsets are equal, `CopyBlock` returns before its
range checks. `ModKern` then advances the output cursor by 512 and publishes a
516-byte table although only ten bytes were supplied or copied. Public
`GlyphTypeface.ComputeSubset` returns 506 unwritten native-allocation bytes.

Five fresh controls retained a ten-byte `kern` with no expansion. Five fresh
attackers returned a 516-byte `kern`; all 506-byte expansions contained
nonzero data and all hashes differed. At the exact branch, a debugger run
returned the full expansion as Windows debug-heap `F00DBAAD` fill.

### Exact target

- Microsoft .NET / `Microsoft.WindowsDesktop.App` 10.0.14 x64
- Windows 11 Home 25H2 x64 build `26200.9711`; BuildLabEx
  `26100.1.amd64fre.ge_release.240331-1435`
- `PresentationCore.dll` 10.0.1426.52326, SHA-256
  `131faa87bce352c2c7ea02fa6d6c36533992fd77a3bf429d1145d21ef3650f1d`
- `DirectWriteForwarder.dll` 10.0.1426.52326 / product
  `10.0.14-servicing.26522.126`, commit
  `0427b9abbead3fa64c6655eb4290c537397131fa`, SHA-256
  `84a254d16d68bdea52981338cb9ed5a2cc52369b51c8c91e72c4714ee2ad199e`

Other versions and architectures were not executed and are not claimed.

### Attack conditions and attacker return path

An attacker supplies a malformed TrueType font to a host that subsets it
through WPF. Impact requires that host to return or store the generated subset
where the supplier can read it. No administrator rights, debugger, disabled
mitigation, or memory/control-flow modification is required. Required user
action and remote reachability depend on the host; WPF alone is not asserted
to create a network or tenant boundary.

`ModKern` publishes the expanded native table. `TrueTypeSubsetter.ComputeSubset`
copies the native output into managed memory, and public
`GlyphTypeface.ComputeSubset` returns it as `byte[]`. A host exposing that
result exposes the unwritten bytes to the supplier.

### Root cause and violated invariant

At WPF tag `v10.0.14`, `modtable.cpp:642-648` checks only that the number of
six-byte subtable headers fits the directory length. It does not validate each
declared nested range. Lines 654-665 make first-subtable source and target
equal and call `CopyBlock(..., 512)`. `ttftabl1.cpp:566` returns on equality
before `CheckInOffset` and `CheckOutOffset`. Because format 1 is not rewritten,
line 679 advances by 512 and line 686 publishes length 516.

Invariant: each nested range and each published output byte must be within the
original logical table or explicitly initialized. Equal copy offsets must not
bypass validation.

Sources:
https://github.com/dotnet/wpf/blob/v10.0.14/src/Microsoft.DotNet.Wpf/src/DirectWriteForwarder/CPP/TrueTypeSubsetter/TtfDelta/modtable.cpp#L603-L688
https://github.com/dotnet/wpf/blob/v10.0.14/src/Microsoft.DotNet.Wpf/src/DirectWriteForwarder/CPP/TrueTypeSubsetter/TtfDelta/ttftabl1.cpp#L554-L588

### Debugger evidence and call stack

The dump captures `CopyBlock+0x20` with
`target=0xed0 source=0xed0 size=0x200`; the following equality jump skips both
range checks. Stack:

```text
DirectWriteForwarder!CopyBlock
DirectWriteForwarder!ModKern+0x1ac
DirectWriteForwarder!CreateDeltaTTFEx+0x553
DirectWriteForwarder!CreateDeltaTTF+0x3ef
DirectWriteForwarder!MS.Internal.TrueTypeSubsetter.ComputeSubset+0x1a4
PresentationCore!TrueTypeFontDriver.ComputeFontSubset+0x8a
PresentationCore!GlyphTypeface.ComputeSubset+0xb6
WpfKernLengthHarness!Program.Main+0x65e
```

Included `.dump /mpwdF` SHA-256:
`3ffafe0b3c9d5582e829f551a58a963a3e37cdd23bcc03194a33ac417d8b34e9`.

### Confirmed impact and limits

Confirmed: 506 bytes not supplied by the input and not initialized by this
path are returned in the font. No real secret was identified. I do not claim
an attacker-selected address, OOB write, crash, RCE, EoP, tenant impact,
Important/Critical severity, CVE assignment, or bounty qualification. Host
behavior determines whether a security boundary is crossed.

### Distinctness and duplicate uncertainty

`VULN-256462` is a format-0 excessive-pair-count read in `AdjustKernFormat0`.
This report never enters that function: it uses format 1, `CopyBlock`'s
equality fast path, and directory expansion over unwritten output. Public PRs
#11835 and #11877 do not cover this range. No exact public report was found,
but a private duplicate remains possible. The .NET program's severity
threshold and common server-side-information-disclosure exclusion are
acknowledged.

## Steps to reproduce

1. On clean Windows x64, install or extract .NET SDK 10.0.403 and official
   Windows Desktop Runtime 10.0.14 x64.
2. Extract the attachment and run:

   ```powershell
   powershell -NoLogo -NoProfile -ExecutionPolicy Bypass `
     -File .\run.ps1 `
     -SdkDotnet "C:\path\to\sdk-10.0.403\dotnet.exe" `
     -RuntimeDotnet "C:\path\to\runtime-10.0.14\dotnet.exe" `
     -Python python -RepeatCount 5
   ```

3. Confirm:

   ```text
   control_count=5
   attacker_count=5
   control_unique_output_hashes=1
   attacker_unique_output_hashes=5
   verification=PASS
   ```

Each control row has `kern_length=10`, `expansion_length=0`. Each attacker row
has `kern_length=516`, `expansion_length=506`, and nonzero returned bytes.
Exact bytes may differ because they are uninitialized.

Fixture hashes:

```text
control  aad90de39d0c0bc43461f9c30c6b846b5f35fdc5cf17057c52b986e3669f07b4
attacker 1ef1c842d8e9beefd859b31558aaf49aff57540bfc57cb8b548ffc44c5e05fed
```

The attachment includes C# source/project files, source generator, fixtures,
ten raw outputs, verifier, debugger output/log/script, and the user dump.

## Other proposed values

- Product/program: Microsoft .NET — .NET Bounty Program
- Product version: `Microsoft.WindowsDesktop.App` 10.0.14 x64
- Security impact: Information Disclosure
- Vulnerability type: CWE-200 / CWE-457 (uninitialized memory exposure)
- Component: WPF `DirectWriteForwarder.dll` / TtfDelta / `ModKern`, `CopyBlock`
- Component version: 10.0.1426.52326; commit
  `0427b9abbead3fa64c6655eb4290c537397131fa`
- Related issue: distinct from `VULN-256462`; related public hardening PRs
  #11835 and #11877 do not cover this path
- Cross-tenant impact: N/A; no Microsoft tenant tested
- Actively exploited: I don't know
- Public disclosure: not publicly reported by me; no disclosure plan
- Acknowledgement: Anonymous
- CVSS: leave blank for MSRC

