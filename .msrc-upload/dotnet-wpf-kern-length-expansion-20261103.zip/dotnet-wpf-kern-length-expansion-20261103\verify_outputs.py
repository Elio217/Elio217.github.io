#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import struct
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def table_range(font: bytes, wanted: bytes) -> tuple[int, int]:
    if len(font) < 12:
        raise ValueError("truncated sfnt header")
    table_count = struct.unpack_from(">H", font, 4)[0]
    for index in range(table_count):
        entry = 12 + 16 * index
        tag, _checksum, offset, length = struct.unpack_from(">4sIII", font, entry)
        if tag == wanted:
            if offset + length > len(font):
                raise ValueError("table exceeds font buffer")
            return offset, length
    raise ValueError(f"missing table {wanted!r}")


def inspect(group: str, path: Path, input_kern_length: int) -> dict[str, object]:
    font = path.read_bytes()
    offset, length = table_range(font, b"kern")
    expansion = font[offset + input_kern_length : offset + length]
    row: dict[str, object] = {
        "group": group,
        "file": path.name,
        "size": len(font),
        "kern_length": length,
        "expansion_length": len(expansion),
        "nonzero_expansion": sum(value != 0 for value in expansion),
        "expansion_sha256": hashlib.sha256(expansion).hexdigest(),
        "file_sha256": hashlib.sha256(font).hexdigest(),
    }
    print(
        f"{row['group']},{row['file']},{row['size']},{row['kern_length']},"
        f"{row['expansion_length']},{row['nonzero_expansion']},"
        f"{row['expansion_sha256']},{row['file_sha256']}"
    )
    return row


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--input-font",
        type=Path,
        default=ROOT / "fixtures" / "kern-format1-length-512.ttf",
    )
    parser.add_argument(
        "--control-font",
        type=Path,
        default=ROOT / "fixtures" / "kern-format1-length-6.ttf",
    )
    parser.add_argument(
        "--evidence-root",
        type=Path,
        default=ROOT / "evidence",
    )
    args = parser.parse_args()

    input_font = args.input_font.read_bytes()
    input_offset, input_kern_length = table_range(input_font, b"kern")
    control_font = args.control_font.read_bytes()
    control_offset, control_kern_length = table_range(control_font, b"kern")
    attacker_kern = input_font[input_offset : input_offset + input_kern_length]
    control_kern = control_font[control_offset : control_offset + control_kern_length]
    assert attacker_kern == bytes.fromhex("00000001000102000101")
    assert control_kern == bytes.fromhex("00000001000100060101")

    rows: list[dict[str, object]] = []
    print("group,file,size,kern_length,expansion_length,nonzero_expansion,expansion_sha256,file_sha256")
    for group in ("clean-control", "clean-attacker"):
        for path in sorted((args.evidence_root / group).glob("*.ttf")):
            rows.append(inspect(group, path, input_kern_length))

    controls = [row for row in rows if row["group"] == "clean-control"]
    attackers = [row for row in rows if row["group"] == "clean-attacker"]
    assert controls, "no control outputs"
    assert attackers, "no attacker outputs"
    assert all(row["kern_length"] == 10 for row in controls)
    assert all(row["expansion_length"] == 0 for row in controls)
    assert all(row["nonzero_expansion"] == 0 for row in controls)
    assert all(row["kern_length"] == 516 for row in attackers)
    assert all(row["expansion_length"] == 506 for row in attackers)
    assert all(int(row["nonzero_expansion"]) > 0 for row in attackers)

    print(f"control_count={len(controls)}")
    print(f"attacker_count={len(attackers)}")
    print(f"control_unique_output_hashes={len({row['file_sha256'] for row in controls})}")
    print(f"attacker_unique_output_hashes={len({row['file_sha256'] for row in attackers})}")
    print("verification=PASS")


if __name__ == "__main__":
    main()
