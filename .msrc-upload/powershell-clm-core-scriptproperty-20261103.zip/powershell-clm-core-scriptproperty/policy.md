# Policy and scope — verified 2026-11-03

## Individual program

Microsoft Open Source Bounty Program:
https://www.microsoft.com/en-us/msrc/opensourcebountyprogram

FACT — PowerShell 7 is explicitly listed in scope. Eligible reports must have
a direct, demonstrable Critical or Important impact and reproduce on the most
recent actively maintained branch. Local-machine-only findings normally
excluded by the program have an explicit PowerShell exception.

Assessment:

- Fixability: **yes, likely**. The guard is product code and the one-condition
  change removes the behavior.
- Program scope: **product is in scope**.
- Bounty qualification: **uncertain**. Important severity is not established;
  the existing trusted-module prerequisite may reduce impact.
- Complete-report status: assessed separately in `complete-checklist.md`.

## Security boundary documentation

Microsoft Learn, Use App Control to secure PowerShell:
https://learn.microsoft.com/en-us/powershell/scripting/security/app-control/application-control

Microsoft documents that App Control runs policy-approved scripts and modules
in FullLanguage while other scripts and scriptblocks are untrusted and run in
ConstrainedLanguage. The documented restrictions exist to prevent untrusted
code from performing dangerous method and property operations.

Microsoft Learn, about_Language_Modes:
https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_language_modes

The page also states that direct assignment of
`LanguageMode = ConstrainedLanguage` is useful for experimentation but does
not reproduce all system-policy restrictions. The report therefore does not
claim an enforced-WDAC test.

## General vulnerability definition

https://www.microsoft.com/en-us/msrc/definition-of-a-security-vulnerability

The observed weakness changes product behavior and permits a protection
mechanism to be bypassed. Whether the prerequisite produces sufficient
customer impact for servicing or bounty is an MSRC decision.

## Complete-report requirements

https://www.microsoft.com/en-us/msrc/requirements-for-complete-vulnerability-reports

For Microsoft-owned open-source software, the report must provide the
repository URL and a PoC against a running project instance, in addition to
the general reproducibility, root-cause, environment, attack-condition, and
impact requirements.

## Rules, safe harbor, and disclosure

- Rules of Engagement, Safe Harbor, terms, and CVD are linked from:
  https://www.microsoft.com/en-us/msrc/bounty-guidelines
- Tests used only researcher-controlled local processes and synthetic data.
- No public disclosure is authorized or planned.
- CVE, severity, servicing, duplicate, and bounty outcomes are not claimed.

