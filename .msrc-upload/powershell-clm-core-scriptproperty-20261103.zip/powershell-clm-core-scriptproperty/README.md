# PowerShell CLM core-object ScriptProperty setter bypass

## Current conclusion

**Status: reproduced; Complete-report attachment.**

PowerShell 7.6.9, 7.7.0-rc.1, and current `master` allow a
`PSScriptProperty` or `PSAliasProperty` instance member to execute when its
base object is a CLM core type such as `Hashtable`. A CLM caller can therefore
invoke a setter created in a trusted module's `FullLanguage` session state.

The positive case reproduced 3/3 in fresh official RC processes. Direct
restricted method invocation and the same ScriptProperty on a non-core object
were blocked. A one-condition source fix blocked ScriptProperty and
AliasProperty while preserving NoteProperty assignment.

The important limitation is that CLM cannot create the FullLanguage setter
from a string. Exploitation requires an existing trusted/full-language module
to return a core object with such an instance member. No built-in Microsoft
module gadget and no system-enforced WDAC deployment were demonstrated.

## Evidence index

- [Final report](report.md)
- [Root-cause analysis](analysis.md)
- [Independent reproduction](reproduction.md)
- [Observed results](observations.md)
- [Policy and scope](policy.md)
- [Novelty and related fixes](duplicate-analysis.md)
- [Complete-report checklist](complete-checklist.md)
- [Proposed minimal source fix](proposed-fix.patch)
- PoC: `poc/`
- Raw evidence: `evidence/`
- Integrity manifest: `hashes.sha256`

## Next action

Start with `reproduction.md`, using a fresh marker path for each case. The
system-enforced WDAC limitation and trusted-module prerequisite are material
parts of the report. The attachment does not claim RCE, EoP, CVE assignment,
MSRC severity, or bounty eligibility.

