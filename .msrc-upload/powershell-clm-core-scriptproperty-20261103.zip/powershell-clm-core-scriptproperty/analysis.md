# Analysis

## Hypothesis

> A CLM caller that receives a PowerShell core object from a trusted
> FullLanguage module can assign an instance `PSScriptProperty` or an alias to
> one, causing its FullLanguage setter to execute despite CLM's property-setter
> restrictions.

Who controls what: the untrusted CLM caller controls the assigned value. A
trusted module controls the returned core object and its pre-existing setter.
The condition is that the base object passes `CoreTypes.Contains`, for example
`System.Collections.Hashtable`.

## Invariant

Untrusted CLM code must not invoke a dynamic ScriptProperty setter merely
because the object's base CLR type is a core type. For instance members, the
safety decision must be based on the member implementation as well as the base
type. Only an exact `PSNoteProperty` should be a data-only write.

## Data flow and root cause

FACT — property assignment reaches
`PSSetMemberBinder.SetInstanceMemberValue()` in:

`src/System.Management.Automation/engine/runtime/Binding/Binders.cs`.

At tags `v7.6.9`, `v7.7.0-rc.1`, and master
`2725d6aaa6e67219b6c9902adf7b74c52e0371a3`, the method:

1. detects CLM and a member whose exact runtime type is not
   `PSNoteProperty`;
2. unwraps the target with `PSObject.Base(target)`;
3. throws only when the base object is null or is not in `CoreTypes`;
4. otherwise executes `memberInfo.Value = value`.

Source link:

https://github.com/PowerShell/PowerShell/blob/2725d6aaa6e67219b6c9902adf7b74c52e0371a3/src/System.Management.Automation/engine/runtime/Binding/Binders.cs#L6483-L6520

FACT — `Hashtable` is listed in `CoreTypes`, so step 3 treats it as safe even
though the invoked implementation is a separately attached
`PSScriptProperty` setter. The setter's ScriptBlock retains the trusted
module's FullLanguage session state.

FACT — the trusted fixture module is imported while its module session state
is FullLanguage. Only after the caller enters CLM does it call the exported
factory and receive the object. Assignment then writes a marker through
`[IO.File]::WriteAllText`, and the marker records
`language=FullLanguage`.

FACT — an otherwise identical ScriptProperty on `StringBuilder` is rejected
with `PropertySetterNotSupportedInConstrainedLanguage`. Direct
`[IO.File]::WriteAllText` from the CLM caller is rejected with
`MethodInvocationNotSupportedInConstrainedLanguage`.

FACT — replacing the core-type exception with an unconditional reject for
non-NoteProperty instance members blocks both the ScriptProperty and
AliasProperty cases. NoteProperty assignment continues to work.

## Confirmed impact

FACT — attacker-controlled assignment from CLM reaches and executes a setter
whose effective language mode is FullLanguage. The test setter performs a
.NET method invocation that the same CLM caller cannot perform directly. This
is a demonstrated CLM protection-mechanism bypass across a modeled trusted
module boundary.

FACT — no debugger, register/memory modification, reflection, process
injection, network service, third-party data, or elevated token is used.

## Limits and contrary evidence

FACT — CLM-created string setters are blocked by
`ConversionSupportedOnlyToCoreTypes`; the attacker cannot create the required
FullLanguage ScriptBlock through `Add-Member` in the tested configuration.

FACT — the host had no enforced App Control/WDAC policy. The reproduction uses
the same explicit `LanguageMode = ConstrainedLanguage` testing mechanism used
by upstream regression tests and separately records the module's
FullLanguage state.

FACT — source and installed-module searches did not identify a default
Microsoft module that returns a core object with a writable instance
ScriptProperty suitable as a gadget.

INFERENCE — a policy-trusted module with this object pattern is a realistic
cross-trust consumer, because Microsoft's documented design runs trusted
modules in FullLanguage and untrusted code in CLM. The frequency of this
pattern in real deployments is unknown.

HYPOTHESIS — a real gadget could provide a stronger impact such as arbitrary
code execution. That was not demonstrated and is not claimed.

## Proposed classification

- Security Feature Bypass / Protection Mechanism Failure
- Proposed CWE-693; MSRC should make the final classification
- Proposed severity: potentially Important because it crosses the App
  Control/CLM trust boundary, but the prerequisite may reduce severity and
  bounty eligibility. No MSRC severity decision is claimed.

