# MSRC Complete checklist — 2026-11-03

Source:
https://www.microsoft.com/en-us/msrc/requirements-for-complete-vulnerability-reports

## General requirements

- [x] Ordered reproduction starts from official PowerShell archives.
- [x] Minimized PoC uses a fresh process and no debugger manipulation.
- [x] Type: Security Feature Bypass / Protection Mechanism Failure.
- [x] Root cause identifies the member-type check and core-type exception.
- [x] Exact versions, commits, platforms, binaries, source, and hashes fixed.
- [x] Starting attacker capability and trusted-module prerequisite stated.
- [x] Confirmed FullLanguage setter execution is separated from hypothetical
  RCE, EoP, and built-in gadget impact.
- [x] Positive 3/3 and three independent negative/normal controls included.
- [x] Contrary evidence from CLM-created string setter is included.
- [x] Portal narrative contains the required facts directly.

## Microsoft-owned open-source additions

- [x] Repository URL: https://github.com/PowerShell/PowerShell
- [x] PoC against official running 7.6.9 and 7.7.0-rc.1 processes.
- [x] PoC against release build from current master commit
  `2725d6aaa6e67219b6c9902adf7b74c52e0371a3`.

## Program qualification kept separate

- [x] PowerShell 7 explicitly in the Open Source Bounty Program.
- [x] Local-machine PowerShell exception confirmed.
- [x] Product-code correction demonstrated.
- [ ] Important severity is a researcher proposal, not an MSRC finding.
- [ ] No default built-in Microsoft gadget was demonstrated.
- [ ] No system-enforced WDAC/App Control policy was tested.
- [ ] Private/internal duplicate cannot be excluded.

## Submission gate

- [ ] Final attachment archive created and independently enumerated.
- [ ] Internal and external SHA-256 manifests verified.
- [ ] Portal fields copied in full; not attachment-only.
- [ ] Anonymous toggle and no-public-disclosure option verified.
- [ ] Portal AI review completed with no unresolved issue.
- [ ] Receipt, timestamp, case ID/submission ID, exact fields, and attachment
  hash preserved.

