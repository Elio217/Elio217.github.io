# Public overlap and novelty check

Checked 2026-11-03.

## Closely related public fixes

PR #28206:
https://github.com/PowerShell/PowerShell/pull/28206

Commit:
https://github.com/PowerShell/PowerShell/commit/b366b2dd9817fd98a796f1224c296b2a0a045386

This change introduced `SetInstanceMemberValue()` and regression tests that
reject ScriptProperty and AliasProperty writes on a non-core
`System.Text.StringBuilder`. Its code explicitly exempts core base types.

PR #28207:
https://github.com/PowerShell/PowerShell/pull/28207

This separately protects property assignment through `.ForEach()` on
non-core types.

## Difference in this report

The reported trigger uses an instance ScriptProperty or AliasProperty on a
core `Hashtable`. This enters the public guard but passes because
`CoreTypes.Contains(baseObject.GetType())` is true. The public tests cover only
non-core targets. Removing the core exception blocks this report while
preserving NoteProperty behavior.

The PR issue comment, review, and review-comment feeds were inspected. They
discuss non-core setters and a `ToString` regression but do not mention this
core-object dynamic-member case. Targeted GitHub issue and web searches found
no exact public report for a Hashtable/core-object ScriptProperty setter in
CLM.

## Uncertainty

INFERENCE — this is an incomplete-fix variant rather than the exact behavior
demonstrated in the public tests.

No public search can exclude a private report, internal Microsoft knowledge,
an unindexed discussion, or a later duplicate. Because the vulnerable core
exception is visible in the public fix, MSRC may consider the condition known.
The submission must disclose this overlap rather than claim novelty.

