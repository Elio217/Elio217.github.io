# Observations

## FACT — official PowerShell 7.7.0-rc.1 Windows

Positive `CoreScriptProperty` reproduced in three fresh processes: 3/3.

Each run recorded:

- target `System.Collections.Hashtable`;
- member `ScriptProperty`;
- caller `ConstrainedLanguage` before and after assignment;
- completed assignment;
- marker created by setter in `FullLanguage` with attacker-controlled value.

Representative evidence:

- `module-rc1-run1/result.json`
- `module-rc1-run2/result.json`
- `module-rc1-run3/result.json`

Controls:

- `module-rc1-noncore/result.json`: blocked, no marker;
- `module-rc1-direct/result.json`: blocked, no marker;
- `module-rc1-note/result.json`: normal data assignment, no marker;
- `module-rc1-alias/result.json`: AliasProperty reaches the same setter.

## FACT — official PowerShell 7.6.9

- Windows core case: reproduced 1/1.
- Linux core case: reproduced 1/1.
- Windows non-core and direct-call controls: both blocked.

Evidence directories begin with `module-769-`.

## FACT — current master

Commit:
`2725d6aaa6e67219b6c9902adf7b74c52e0371a3`

Release build on Ubuntu 24.04.4 reproduced ScriptProperty and AliasProperty.
Non-core and direct-call controls were blocked. After a clean source restore
and rebuild, `module-master-rebuilt/result.json` reproduced once more.

Vulnerable master `System.Management.Automation.dll` SHA-256:
`1b605ca8920844ab04a7b7315eead133e45a255e330d8af7a21e2173754346bb`.

## FACT — proposed fix differential

A release build with only the core-type exception removed produced:

- `module-fixed-core`: blocked, no marker;
- `module-fixed-alias`: blocked, no marker;
- `module-fixed-note`: allowed, value changed, no marker.

Fixed DLL SHA-256:
`67b51f4de403d0baa74db9a16912c97b7c4241901f544291d5f53f63b0227dc0`.

The fixed DLL is evidence only; the product source tree was restored and
rebuilt from unmodified master after this differential test.

## FACT — environment

- Windows reported by `ver`: `10.0.26200.9711`, DisplayVersion `25H2`.
- Required registry BuildLabEx value:
  `26100.1.amd64fre.ge_release.240331-1435`.
- Token integrity: Medium; tests were not elevated.
- WSL/Linux: Ubuntu 24.04.4 LTS.
- No debugger or enforced WDAC policy was used.

