# Independent reproduction

## Target

Repository: https://github.com/PowerShell/PowerShell

Primary official target:

- PowerShell `7.7.0-rc.1` Windows x64 portable
- ZIP SHA-256:
  `2bb33156e2acefe127a9a5e88583aec9835ee005a215c68280e346b6ebb44182`
- `System.Management.Automation.dll` SHA-256:
  `f1ec74153b6892ee063752ab88bf1d1a715d91d824fad1e5d41b47d04429a0ec`

The PoC also reproduces on official 7.6.9 Windows/Linux and current master.

## Files

- `TrustedFixture.psm1`
- `run-module-boundary.ps1`

Both are in the attachment's `poc` directory.

## Positive test

From a normal, non-elevated Windows terminal after extracting PowerShell and
the attachment:

```powershell
& C:\path\to\pwsh.exe -NoLogo -NoProfile -NonInteractive -File `
  .\poc\run-module-boundary.ps1 `
  -Case CoreScriptProperty `
  -MarkerPath .\new-evidence\core\marker.txt
```

Expected fields:

```json
{
  "ModuleLanguageMode": "FullLanguage",
  "TargetType": "System.Collections.Hashtable",
  "MemberType": "ScriptProperty",
  "LanguageDuring": "ConstrainedLanguage",
  "AssignmentOutcome": "completed",
  "MarkerExists": true,
  "MarkerContents": "TRUSTED_SETTER_EXECUTED|language=FullLanguage|value=attacker-controlled-value"
}
```

Run the command three times with a new marker path. Each marker must not exist
before the run.

## Negative controls

Use a new marker path for each command:

```powershell
& C:\path\to\pwsh.exe -NoLogo -NoProfile -NonInteractive -File `
  .\poc\run-module-boundary.ps1 -Case NonCoreScriptProperty `
  -MarkerPath .\new-evidence\noncore\marker.txt

& C:\path\to\pwsh.exe -NoLogo -NoProfile -NonInteractive -File `
  .\poc\run-module-boundary.ps1 -Case DirectRestrictedCall `
  -MarkerPath .\new-evidence\direct\marker.txt

& C:\path\to\pwsh.exe -NoLogo -NoProfile -NonInteractive -File `
  .\poc\run-module-boundary.ps1 -Case CoreNoteProperty `
  -MarkerPath .\new-evidence\note\marker.txt
```

Expected:

- non-core ScriptProperty: exception
  `PropertySetterNotSupportedInConstrainedLanguage`, no marker;
- direct restricted call: exception
  `MethodInvocationNotSupportedInConstrainedLanguage`, no marker;
- core NoteProperty: assignment completes and value changes, no marker.

## Alias variant

`-Case CoreAliasProperty` creates an AliasProperty on the core object that
resolves to the ScriptProperty. It also executes the FullLanguage setter. This
is evidence for the same root cause, not a separate vulnerability.

## Tested limitation

`probe-clm-created.ps1 -Case StringSetter` attempts to create the setter from a
string only after entering CLM. Expected result is
`ConversionSupportedOnlyToCoreTypes` and no marker. This proves the positive
case requires a pre-existing FullLanguage setter.

## Configuration caveat

This PoC models the documented trust split by importing a fixture module in
FullLanguage, switching the caller to CLM, and only then calling the module to
receive the object. It does not install or claim a system-enforced WDAC policy.
The limitation is intentional to avoid changing host security policy and is
part of the report's attack conditions.

