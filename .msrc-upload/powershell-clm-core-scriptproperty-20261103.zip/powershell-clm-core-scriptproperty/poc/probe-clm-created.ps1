param(
    [Parameter(Mandatory)]
    [ValidateSet('StringSetter', 'DirectRestrictedCall')]
    [string] $Case,

    [Parameter(Mandatory)][string] $MarkerPath
)

$ErrorActionPreference = 'Stop'
$marker = [IO.Path]::GetFullPath($MarkerPath)
$markerParent = [IO.Path]::GetDirectoryName($marker)
[IO.Directory]::CreateDirectory($markerParent) | Out-Null
if ([IO.File]::Exists($marker)) {
    throw "Marker must not exist before the test: $marker"
}

$escapedMarker = $marker.Replace("'", "''")
$setterText = @"
param(`$newValue)
`$language = `$ExecutionContext.SessionState.LanguageMode.ToString()
[IO.File]::WriteAllText('$escapedMarker', "CLM_CREATED_SETTER_EXECUTED|language=`$language|value=`$newValue")
"@

$powerShellVersion = $PSVersionTable.PSVersion.ToString()
$gitCommitId = $PSVersionTable.GitCommitId
$operatingSystem = $PSVersionTable.OS
$languageBefore = $ExecutionContext.SessionState.LanguageMode.ToString()
$ExecutionContext.SessionState.LanguageMode = 'ConstrainedLanguage'
$languageDuring = $ExecutionContext.SessionState.LanguageMode.ToString()

$target = @{}
$creationOutcome = 'not-applicable'
$creationErrorId = $null
$creationErrorMessage = $null
$assignmentOutcome = 'not-run'
$assignmentErrorId = $null
$assignmentErrorMessage = $null

try {
    if ($Case -eq 'StringSetter') {
        $creationOutcome = 'completed'
        $target | Add-Member -MemberType ScriptProperty -Name Trigger -Value "'getter-control'" -SecondValue $setterText
        $assignmentOutcome = 'completed'
        $target.Trigger = 'attacker-controlled-value'
    }
    else {
        $assignmentOutcome = 'completed'
        [IO.File]::WriteAllText($marker, 'DIRECT_RESTRICTED_CALL_EXECUTED')
    }
}
catch {
    if (($Case -eq 'StringSetter') -and ($creationOutcome -eq 'completed') -and
        ($target.PSObject.Properties['Trigger'] -eq $null)) {
        $creationOutcome = 'exception'
        $creationErrorId = $_.FullyQualifiedErrorId
        $creationErrorMessage = $_.Exception.Message
    }
    else {
        $assignmentOutcome = 'exception'
        $assignmentErrorId = $_.FullyQualifiedErrorId
        $assignmentErrorMessage = $_.Exception.Message
    }
}

$markerExists = Test-Path -LiteralPath $marker -PathType Leaf
$markerContents = if ($markerExists) { Get-Content -LiteralPath $marker -Raw } else { $null }

[ordered]@{
    Case = $Case
    PowerShell = $powerShellVersion
    GitCommitId = $gitCommitId
    OS = $operatingSystem
    LanguageBefore = $languageBefore
    LanguageDuring = $languageDuring
    LanguageAfter = $ExecutionContext.SessionState.LanguageMode.ToString()
    TargetType = $target.PSObject.TypeNames[0]
    MemberType = if ($null -ne $target.PSObject.Properties['Trigger']) { [string]$target.PSObject.Properties['Trigger'].MemberType } else { $null }
    CreationOutcome = $creationOutcome
    CreationErrorId = $creationErrorId
    CreationErrorMessage = $creationErrorMessage
    AssignmentOutcome = $assignmentOutcome
    AssignmentErrorId = $assignmentErrorId
    AssignmentErrorMessage = $assignmentErrorMessage
    MarkerExists = $markerExists
    MarkerContents = $markerContents
} | ConvertTo-Json -Depth 5
