function New-TrustedCoreScriptPropertyObject {
    param([Parameter(Mandatory)][string] $MarkerPath)

    $capturedMarker = [IO.Path]::GetFullPath($MarkerPath)
    $getter = { 'getter-control' }.GetNewClosure()
    $setter = {
        param($newValue)
        $language = $ExecutionContext.SessionState.LanguageMode.ToString()
        [IO.File]::WriteAllText(
            $capturedMarker,
            "TRUSTED_SETTER_EXECUTED|language=$language|value=$newValue")
    }.GetNewClosure()

    $result = @{}
    $result | Add-Member -MemberType ScriptProperty -Name Trigger -Value $getter -SecondValue $setter
    return $result
}

function New-TrustedCoreAliasPropertyObject {
    param([Parameter(Mandatory)][string] $MarkerPath)

    $capturedMarker = [IO.Path]::GetFullPath($MarkerPath)
    $getter = { 'getter-control' }.GetNewClosure()
    $setter = {
        param($newValue)
        $language = $ExecutionContext.SessionState.LanguageMode.ToString()
        [IO.File]::WriteAllText(
            $capturedMarker,
            "TRUSTED_SETTER_EXECUTED|language=$language|value=$newValue")
    }.GetNewClosure()

    $result = @{}
    $result | Add-Member -MemberType ScriptProperty -Name BackingTrigger -Value $getter -SecondValue $setter
    $result | Add-Member -MemberType AliasProperty -Name Trigger -Value BackingTrigger
    return $result
}

function New-TrustedNonCoreScriptPropertyObject {
    param([Parameter(Mandatory)][string] $MarkerPath)

    $capturedMarker = [IO.Path]::GetFullPath($MarkerPath)
    $getter = { 'getter-control' }.GetNewClosure()
    $setter = {
        param($newValue)
        $language = $ExecutionContext.SessionState.LanguageMode.ToString()
        [IO.File]::WriteAllText(
            $capturedMarker,
            "TRUSTED_SETTER_EXECUTED|language=$language|value=$newValue")
    }.GetNewClosure()

    $result = [Text.StringBuilder]::new()
    $result | Add-Member -MemberType ScriptProperty -Name Trigger -Value $getter -SecondValue $setter
    return $result
}

function New-TrustedCoreNotePropertyObject {
    $result = @{}
    $result | Add-Member -MemberType NoteProperty -Name Trigger -Value 'before'
    return $result
}

Export-ModuleMember -Function New-TrustedCoreScriptPropertyObject,
    New-TrustedCoreAliasPropertyObject,
    New-TrustedNonCoreScriptPropertyObject,
    New-TrustedCoreNotePropertyObject
