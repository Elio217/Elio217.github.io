param(
    [Parameter(Mandatory)]
    [ValidateSet('CoreScriptProperty', 'CoreAliasProperty', 'NonCoreScriptProperty', 'CoreNoteProperty', 'DirectRestrictedCall')]
    [string] $Case,

    [Parameter(Mandatory)][string] $MarkerPath
)

$ErrorActionPreference = 'Stop'
$marker = [IO.Path]::GetFullPath($MarkerPath)
$markerParent = [IO.Path]::GetDirectoryName($marker)
[IO.Directory]::CreateDirectory($markerParent) | Out-Null
if ([IO.File]::Exists($marker)) {
    throw "Marker must not exist before the test: $marker"
}

$fixtureModule = Join-Path $PSScriptRoot 'TrustedFixture.psm1'
Import-Module -Name $fixtureModule -Force
$moduleLanguageMode = (Get-Module TrustedFixture).SessionState.LanguageMode.ToString()
$powerShellVersion = $PSVersionTable.PSVersion.ToString()
$gitCommitId = $PSVersionTable.GitCommitId
$operatingSystem = $PSVersionTable.OS
$languageBefore = $ExecutionContext.SessionState.LanguageMode.ToString()

# This models untrusted script consumption after a trusted/full-language module
# has constructed and returned the object. It does not claim a WDAC-enforced run.
$ExecutionContext.SessionState.LanguageMode = 'ConstrainedLanguage'
$languageDuring = $ExecutionContext.SessionState.LanguageMode.ToString()

# These exported functions were loaded in the module's FullLanguage session
# state. The calls occur only after the caller has entered CLM, so the returned
# object crosses the module-to-caller boundary that the test is modeling.
switch ($Case) {
    'CoreScriptProperty' {
        $target = New-TrustedCoreScriptPropertyObject -MarkerPath $marker
    }
    'CoreAliasProperty' {
        $target = New-TrustedCoreAliasPropertyObject -MarkerPath $marker
    }
    'NonCoreScriptProperty' {
        $target = New-TrustedNonCoreScriptPropertyObject -MarkerPath $marker
    }
    'CoreNoteProperty' {
        $target = New-TrustedCoreNotePropertyObject
    }
    'DirectRestrictedCall' {
        $target = $null
    }
}

$targetType = if ($null -ne $target) { $target.PSObject.TypeNames[0] } else { $null }
$memberType = if ($null -ne $target) { [string]$target.PSObject.Properties['Trigger'].MemberType } else { $null }

$outcome = 'completed'
$errorId = $null
$errorMessage = $null
try {
    if ($Case -eq 'DirectRestrictedCall') {
        [IO.File]::WriteAllText($marker, 'DIRECT_RESTRICTED_CALL_EXECUTED')
    }
    else {
        $target.Trigger = 'attacker-controlled-value'
    }
}
catch {
    $outcome = 'exception'
    $errorId = $_.FullyQualifiedErrorId
    $errorMessage = $_.Exception.Message
}

$markerExists = Test-Path -LiteralPath $marker -PathType Leaf
$markerContents = if ($markerExists) { Get-Content -LiteralPath $marker -Raw } else { $null }
$languageAfter = $ExecutionContext.SessionState.LanguageMode.ToString()

[ordered]@{
    Case = $Case
    PowerShell = $powerShellVersion
    GitCommitId = $gitCommitId
    OS = $operatingSystem
    FixtureModule = $fixtureModule
    ModuleLanguageMode = $moduleLanguageMode
    TargetType = $targetType
    MemberType = $memberType
    LanguageBefore = $languageBefore
    LanguageDuring = $languageDuring
    LanguageAfter = $languageAfter
    AssignmentOutcome = $outcome
    ErrorId = $errorId
    ErrorMessage = $errorMessage
    MarkerExists = $markerExists
    MarkerContents = $markerContents
    FinalPropertyValue = if ($Case -eq 'CoreNoteProperty') { $target.Trigger } else { $null }
} | ConvertTo-Json -Depth 5
