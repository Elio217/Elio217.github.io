# PowerShell CLM allows FullLanguage ScriptProperty setters on core objects

## Product and vulnerability type

- Program: Microsoft Open Source Bounty Program
- Product: PowerShell 7
- Repository: https://github.com/PowerShell/PowerShell
- Component: `PSSetMemberBinder.SetInstanceMemberValue()` in
  `System.Management.Automation`
- Type: Security Feature Bypass / Protection Mechanism Failure
- Proposed CWE: CWE-693 (MSRC should select the final classification)

## Summary

PowerShell's Constrained Language Mode (CLM) property-assignment guard rejects
an instance `PSScriptProperty` or `PSAliasProperty` on non-core objects, but
exempts the same dynamic members when the base object is a CLM core type such
as `Hashtable`.

This permits untrusted CLM code to assign a property on a core object returned
by a trusted FullLanguage module. The dynamic setter then executes in the
trusted module's FullLanguage session state. The supplied PoC imports a fixture
module in FullLanguage, switches only the caller to CLM, calls the module to
receive a Hashtable with a ScriptProperty, and assigns an attacker-controlled
value. The setter invokes `[IO.File]::WriteAllText`, while the identical direct
.NET invocation from the CLM caller is rejected. The marker confirms that the
setter executed with `language=FullLanguage`.

The primary official 7.7.0-rc.1 case reproduced in three fresh processes.
Official 7.6.9 Windows/Linux and current master were also affected. A minimal
source change that removes the core-type exception blocks ScriptProperty and
AliasProperty while preserving normal NoteProperty assignment.

## Affected targets tested

1. Official PowerShell 7.6.9 Windows x64 portable, tag
   `bf5fc434120666e5f1a8d1dfd6ecac7efc17a4be`, Windows
   `10.0.26200.9711`, BuildLabEx
   `26100.1.amd64fre.ge_release.240331-1435`.
2. Official PowerShell 7.6.9 Linux x64, same tag, Ubuntu 24.04.4 WSL2.
3. Official PowerShell 7.7.0-rc.1 Windows x64 portable, tag
   `03e75936536fba165d26680ac01f1e1148e6a33d`.
4. Release build from current master commit
   `2725d6aaa6e67219b6c9902adf7b74c52e0371a3`, fetched and built
   2026-11-03.

RC1 reproduced 3/3 for the primary case. Stable Windows, stable Linux, and a
freshly rebuilt master reproduced 1/1 each. Other versions are not claimed.

## Attack conditions and boundary

- The attacker can execute untrusted PowerShell code in CLM in the same
  process as policy-trusted FullLanguage modules.
- A trusted module returns a core object with a pre-existing instance
  ScriptProperty setter or an AliasProperty that resolves to one.
- The attacker assigns a value to that property.
- The attacker controls the assigned value; the trusted module controls the
  fixed setter implementation and its captured resources.

Microsoft documents App Control's trust split: policy-approved modules execute
in FullLanguage while other code executes in CLM. The violated invariant is
that a base type being safe must not automatically make an attached dynamic
ScriptProperty implementation safe.

No elevation, debugger, network service, third-party data, or victim account is
needed for the minimized reproduction. However, the test host did not have an
enforced WDAC/App Control policy; the PoC models the documented split using
PowerShell's explicit language-mode test mechanism. A real deployment must
already contain a trusted module with the described object pattern.

## Root cause

At current master, `SetInstanceMemberValue()` correctly recognizes every
instance member whose exact type is not `PSNoteProperty`. It then unwraps the
target and throws only when the base type is not in `CoreTypes`:

https://github.com/PowerShell/PowerShell/blob/2725d6aaa6e67219b6c9902adf7b74c52e0371a3/src/System.Management.Automation/engine/runtime/Binding/Binders.cs#L6483-L6520

Because `Hashtable` is a core type, the guard falls through to:

```csharp
memberInfo.Value = value;
```

For `PSScriptProperty`, this invokes its setter ScriptBlock. A setter created in
the trusted module's FullLanguage session state remains FullLanguage when the
CLM caller triggers it.

The public PR that introduced this guard tests only a non-core
`StringBuilder`, even though its comment states that only exact
`PSNoteProperty` should be allowed:
https://github.com/PowerShell/PowerShell/pull/28206

## Reproduction

Extract the attachment and official PowerShell 7.7.0-rc.1 Windows x64. The
official ZIP SHA-256 used was:

`2bb33156e2acefe127a9a5e88583aec9835ee005a215c68280e346b6ebb44182`

Run three times with a fresh marker path:

```powershell
& C:\path\to\pwsh.exe -NoLogo -NoProfile -NonInteractive -File `
  .\poc\run-module-boundary.ps1 `
  -Case CoreScriptProperty `
  -MarkerPath .\new-evidence\run1\marker.txt
```

Expected key output:

```text
ModuleLanguageMode: FullLanguage
TargetType: System.Collections.Hashtable
MemberType: ScriptProperty
LanguageDuring: ConstrainedLanguage
AssignmentOutcome: completed
MarkerExists: true
MarkerContents: TRUSTED_SETTER_EXECUTED|language=FullLanguage|value=attacker-controlled-value
```

Then run `NonCoreScriptProperty`, `DirectRestrictedCall`, and
`CoreNoteProperty` using new marker paths. The non-core and direct cases must
throw their CLM restriction errors without a marker. NoteProperty assignment
must complete without invoking a setter.

The attachment contains exact commands, raw JSON from official releases and
master, source, a proposed patch, and SHA-256 hashes.

## Confirmed impact and limits

Confirmed: untrusted CLM property assignment invokes a pre-existing
FullLanguage dynamic setter on a core object and passes it attacker-controlled
data. The test setter performs a .NET method invocation that the caller's CLM
context blocks directly. This is a protection-mechanism boundary crossing.

Not confirmed: a built-in Microsoft module gadget, arbitrary attacker-selected
FullLanguage code, RCE, EoP, persistence, cross-user impact, or a system-policy
WDAC reproduction. CLM cannot create the setter from a string in the tested
build; that attempt fails with `ConversionSupportedOnlyToCoreTypes`. These are
material prerequisites, not omitted assumptions. MSRC should determine
severity, servicing, and bounty eligibility.

## Public overlap

PR #28206 publicly fixes the corresponding non-core case and contains the core
exception. PR #28207 covers the separate `.ForEach()` assignment path. The
public tests, review comments, and targeted issue searches did not identify the
core-object instance-member trigger reported here. Because the relevant code
is public, Microsoft may already know the gap; a private or unindexed duplicate
cannot be excluded. This report is presented as an incomplete-fix variant, not
as guaranteed novel work.

